//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//

// include files
#include "stdafx.h"
#include "windowsx.h"
#include "imm.h"
#include "winuser.h"
#include "resource.h"
#include "sipapi.h"
#include "kimeui.h"
#include "KoreanImeUI.h"
#include "uiInfo.h"
#include <Windev.h>

// local definitions
#define UIGWL_FLAGS     0

#define UIF_WNDMOVE     0x00000001UL
#define UIF_HANPRESS    0x00000002UL
#define UIF_JUNPRESS    0x00000004UL
#define UIF_CHIPRESS    0x00000008UL
#define UIF_MOUSEIN     0x00000010UL
#define UIF_SHOWSTATUS  0x00000020UL
#define UIF_PRIVATEPOS  0x00000040UL

#define IDC_ARROW     MAKEINTRESOURCE(32512)
#define VK_HANGEUL    0x15
#define VK_JUNJA      0x17
#define VK_HANJA      0x19


///////////////////////////////////////////////////////////////////////////////
//extern BOOL fWndOpen[3];
//extern WORD wWndCmd[3];

///////////////////////////////////////////////////////////////////////////////
// Private function declarations

static BOOL State_OnSetCursor(HWND, HWND, UINT, UINT);
static void State_OnMouseMove(HWND, int, int, UINT);
static void State_OnLButtonDown(HWND hwnd, BOOL fDoubleClick, int x, int y, UINT keyFlags);
static void State_OnLButtonUp(HWND, int, int, UINT);
static void State_OnDestroy(HWND hWnd);
static void State_OnPaint(HWND);

static void Comp_OnPaint(HWND);

static BOOL Cand_OnSetCursor(HWND, HWND, UINT, UINT); // ?
static void Cand_OnLButtonDown(HWND, BOOL, int, int, UINT);
static void Cand_OnLButtonUp(HWND, int, int, UINT);
static void Cand_OnPaint(HWND);
static void Cand_OnSetFocus(HWND hwnd, HWND hwndOldFocus); // ?

static void ShowWindowBorder();
static void GetSysColorsAndMappedBitmap(void); // ?

LRESULT CALLBACK StateWndProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK CompWndProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK CandWndProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);

LRESULT CALLBACK VCandWndProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);
static void VCand_OnLButtonDown(HWND, BOOL, int, int, UINT);
static void VCand_OnLButtonUp(HWND, int, int, UINT);
static void VCand_OnMouseMove(HWND hWnd, int x, int y, UINT keyFlags);
static void VCand_OnVScroll(HWND hWnd, HWND hScrollbar, UINT nScrollCode, short int nPos);
static void VCand_OnPaint(HWND);


///////////////////////////////////////////////////////////////////////////////
// public shared data

const TCHAR szStateWndName[] = TEXT("UNIIMESTATE");
const TCHAR szCompWndName[]  = TEXT("UNIIMECOMP");
const TCHAR szCandWndName[]  = TEXT("UNIIMECAND");

const static RECT   rcHan = { 5, 3, 22, 20 }, rcChi = { 25, 3, 42, 20 }, rcAll = { 5, 3, 42, 20};

const static RECT   rcCandCli = { 0, 0, 239, 29 },
                    rcLArrow = { 2, 4, 14, 25 }, rcRArrow = { 225, 4, 236, 25 },
                    rcBtn[9] = {   {  17, 4,  38, 25 }, {  40, 4,  61, 25 },
                                   {  63, 4,  84, 25 }, {  86, 4, 107, 25 },
                                   { 109, 4, 130, 25 }, { 132, 4, 153, 25 },
                                   { 155, 4, 176, 25 }, { 178, 4, 199, 25 },
                                   { 201, 4, 222, 25 }   };

RECT rcVIndex[5], rcVButton[5], rcPage;
SIZE sizeCandScroll;
POINT ptCandScroll;
///////////////////////////////////////////////////////////////////////////////
// Private data
static POINT    ptPos;
static RECT     stateWinRect;
enum _BUTTONSTATE 
    { BTS_NONE, BTS_DOWN };
static enum _BUTTONSTATE    buttonStates[2];    // to repaint when mouse move on IME buttons
#define CLEARBUTTONSTATES() { buttonStates[0] = buttonStates[1] = BTS_NONE; }
static DWORD    fdwUIFlags=0;

///////////////////////////////////////////////////////////////////////////////
//    Global data
HBITMAP     hBMClient, hBMComp, hBMCand, hBMCandNum, hBMCandArr[2];
HBITMAP     hBMEng, hBMHan, hBMBan, hBMJun, 
            hBMChi, hBMChiOn;
HCURSOR     hIMECursor=0;
HFONT       hFontFix = NULL;
int         nSelect = -1;

///////////////////////////////////////////////////////////////////////////////
//

extern LPVOID g_lpSharedUIPos;
#define g_uiInfo    (*(UIINFO *)g_lpSharedUIPos)
#define rcScreen    (*(LPRECT)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)))
#define rcOldScrn   (*(LPRECT)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)+sizeof(RECT)))
#define g_fdwFixedCand        (*(LPDWORD)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)+sizeof(RECT)+sizeof(RECT)))
#define g_fdwVertCand         (*(LPDWORD)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)+sizeof(RECT)+sizeof(RECT)+sizeof(DWORD)))
#define g_fdwAutoCandAccel    (*(LPDWORD)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)+sizeof(RECT)+sizeof(RECT)+sizeof(DWORD)*2))

const TCHAR szIMEKey[]       = TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\MSUNI95K");
const TCHAR szInputMethod[]  = TEXT("InputMethod");
const TCHAR szCompDel[]      = TEXT("CompDel");
const TCHAR szStatePos[]     = TEXT("StatePos");
const TCHAR szCandPos[]      = TEXT("CandPos");
int     g_nCandSizeX, g_nCandSizeY;
SIZE    g_sizeUnit;

LPCANDIDATELIST g_lpCandList = NULL;

WCHAR g_szCompStr[2] = { 0, 0 };
DWORD g_dwStateFlag = 0;

extern HINSTANCE g_hInst;

typedef struct _HOTKEY {
    UINT uVKey;
    UINT uMod;
} HOTKEY;

HOTKEY KorEngToggle, HanjaConvert, CandNextPage, CandPrevPage, CandNext, CandPrev, CandStart, CandEnd;
HOTKEY CandESC;

#define IME_KHOTKEY_CANDESCAPE         (IME_KHOTKEY_FIRST+3)

#define IME_KHOTKEY_CANDNEXT           (IME_KHOTKEY_FIRST+5)
#define IME_KHOTKEY_CANDPREV           (IME_KHOTKEY_FIRST+6)
#define IME_KHOTKEY_CANDNEXTPAGE       (IME_KHOTKEY_FIRST+7)
#define IME_KHOTKEY_CANDPREVPAGE       (IME_KHOTKEY_FIRST+8)
#define IME_KHOTKEY_CANDSTART          (IME_KHOTKEY_FIRST+9)
#define IME_KHOTKEY_CANDEND            (IME_KHOTKEY_FIRST+10)

void ReadHotKey()
{
    HKL hKL;
    if (!ImmGetHotKey( IME_KHOTKEY_CANDESCAPE, &CandESC.uMod, &CandESC.uVKey, &hKL)) {
        CandESC.uVKey = VK_ESCAPE;
        CandESC.uMod = 0x0400;
    }

    if (!ImmGetHotKey( IME_KHOTKEY_ENGLISH, &KorEngToggle.uMod, &KorEngToggle.uVKey, &hKL)) {
        KorEngToggle.uVKey = VK_HANGEUL;
        KorEngToggle.uMod = 0x0400;
    }
    if (!ImmGetHotKey( IME_KHOTKEY_HANJACONVERT, &HanjaConvert.uMod, &HanjaConvert.uVKey, &hKL)) {
        HanjaConvert.uVKey = VK_HANJA;
        HanjaConvert.uMod = 0x0400;
    }
    if (!ImmGetHotKey( IME_KHOTKEY_CANDNEXTPAGE, &CandNextPage.uMod, &CandNextPage.uVKey, &hKL)) {
        CandNextPage.uVKey = VK_NEXT;
        CandNextPage.uMod = 0x0400;
    }
    if (!ImmGetHotKey( IME_KHOTKEY_CANDPREVPAGE, &CandPrevPage.uMod, &CandPrevPage.uVKey, &hKL)) {
        CandPrevPage.uVKey = VK_PRIOR;
        CandPrevPage.uMod = 0x0400;
    }
    if (!ImmGetHotKey( IME_KHOTKEY_CANDNEXT, &CandNext.uMod, &CandNext.uVKey, &hKL)) {
        CandNext.uVKey = g_fdwVertCand ? VK_DOWN : VK_RIGHT;
        CandNext.uMod = 0x0400;
    }
    if (!ImmGetHotKey( IME_KHOTKEY_CANDPREV, &CandPrev.uMod, &CandPrev.uVKey, &hKL)) {
        CandPrev.uVKey = g_fdwVertCand ? VK_UP : VK_LEFT;
        CandPrev.uMod = 0x0400;
    }
    if (!ImmGetHotKey( IME_KHOTKEY_CANDSTART, &CandStart.uMod, &CandStart.uVKey, &hKL)) {
        CandStart.uVKey = VK_HOME;
        CandStart.uMod = 0x0400;
    }
    if (!ImmGetHotKey( IME_KHOTKEY_CANDEND, &CandEnd.uMod, &CandEnd.uVKey, &hKL)) {
        CandEnd.uVKey = VK_END;
        CandEnd.uMod = 0x0400;
    }
}

void PressHotKey(HOTKEY hk)
{
    UINT uAlt, uCtrl, uShift, uRL;
    if (hk.uMod & MOD_IGNORE_ALL_MODIFIER) {
        keybd_event(hk.uVKey, 0, 0, 0);
        keybd_event(hk.uVKey, 0, KEYEVENTF_KEYUP, 0);
        return;
    }
    uCtrl  = hk.uMod & MOD_CONTROL;
    uAlt   = hk.uMod & MOD_ALT;
    uShift = hk.uMod & MOD_SHIFT;
    uRL    = hk.uMod & (MOD_LEFT | MOD_RIGHT);
    
    if (uRL) {
        if (uRL & MOD_RIGHT) {
            if (uCtrl)
                keybd_event(VK_RCONTROL, 0, 0, 0);
            if (uAlt)
                keybd_event(VK_RMENU, 0, 0, 0);
            if (uShift)
                keybd_event(VK_RSHIFT, 0, 0, 0);
            keybd_event(hk.uVKey, 0, 0, 0);
            keybd_event(hk.uVKey, 0, KEYEVENTF_KEYUP, 0);
            if (uShift)
                keybd_event(VK_RSHIFT, 0, KEYEVENTF_KEYUP, 0);
            if (uAlt)
                keybd_event(VK_RMENU, 0, KEYEVENTF_KEYUP, 0);
            if (uCtrl)
                keybd_event(VK_RCONTROL, 0, KEYEVENTF_KEYUP, 0);
        }
        else {
            if (uCtrl)
                keybd_event(VK_LCONTROL, 0, 0, 0);
            if (uAlt)
                keybd_event(VK_LMENU, 0, 0, 0);
            if (uShift)
                keybd_event(VK_LSHIFT, 0, 0, 0);
            keybd_event(hk.uVKey, 0, 0, 0);
            keybd_event(hk.uVKey, 0, KEYEVENTF_KEYUP, 0);
            if (uShift)
                keybd_event(VK_LSHIFT, 0, KEYEVENTF_KEYUP, 0);
            if (uAlt)
                keybd_event(VK_LMENU, 0, KEYEVENTF_KEYUP, 0);
            if (uCtrl)
                keybd_event(VK_LCONTROL, 0, KEYEVENTF_KEYUP, 0);
        }
    }
}

typedef bool (WINAPI *PFNSHSipInfo)(UINT,UINT,PVOID,UINT);
bool GetWorkAreaFromPPCShell(LPRECT prect, SIPINFO *pssi)
{
    PFNSHSipInfo   pfnSHSipInfo;
    HMODULE        hMod;
    
    if (WAIT_OBJECT_0 != WaitForAPIReady(SH_SHELL, 0))
        return false;

    hMod = GetModuleHandle(TEXT("aygshell.dll"));
    if (!hMod) 
        return false;
    pfnSHSipInfo = (PFNSHSipInfo) GetProcAddress(hMod, TEXT("SHSipInfo"));
    if (!pfnSHSipInfo)
        return false;

    if ((*pfnSHSipInfo)(SPI_GETSIPINFO, 0, (PVOID) pssi, 0)) {
        RETAILMSG(1,(TEXT("GetWorkAreaFromPPCShell() rcVisibleDesktop = (%d, %d - %d, %d)\n"), 
            pssi->rcVisibleDesktop.left, pssi->rcVisibleDesktop.top, 
            pssi->rcVisibleDesktop.right, pssi->rcVisibleDesktop.bottom));
            
        *prect = pssi->rcVisibleDesktop;
        return true;
    }
    return false;
}

void GetWorkArea(LPRECT lprcWorkArea)
{
    SIPINFO  sSipInfo;

    memset(&sSipInfo, 0, sizeof(SIPINFO));
    sSipInfo.cbSize = sizeof(SIPINFO);
    sSipInfo.dwImDataSize = 0;
    sSipInfo.pvImData = NULL;
    if (!GetWorkAreaFromPPCShell(lprcWorkArea, &sSipInfo)) {    // check AYGSHELL first
        if (SipGetInfo(&sSipInfo)) {
            *lprcWorkArea = sSipInfo.rcVisibleDesktop;
        } else {
            SystemParametersInfo(SPI_GETWORKAREA, 0, lprcWorkArea, 0);
        }
    }
}

BOOL IsSIPOn()
{
    SIPINFO  sSipInfo;
    sSipInfo.cbSize = sizeof(SIPINFO);
    sSipInfo.dwImDataSize = 0;
    sSipInfo.pvImData = NULL;
    if (SipGetInfo(&sSipInfo) && (sSipInfo.fdwFlags & SIPF_ON))
        return TRUE;
    return FALSE;
}

// to avoid SIP region
typedef bool (WINAPI *PFNSHSipInfo)(UINT,UINT,PVOID,UINT);

BOOL CheckRectForSIP(const RECT * lprcRect)
{
    SIPINFO sSipInfo;
    RECT    rcScr;
    RECT    rcTmp1, rcTmp2;

    PFNSHSipInfo   pfnSHSipInfo;
    HMODULE        hMod;

    memset(&sSipInfo, 0, sizeof(SIPINFO));
    sSipInfo.cbSize = sizeof(SIPINFO);
    sSipInfo.dwImDataSize = 0;
    sSipInfo.pvImData = NULL;

    if (WAIT_OBJECT_0 != WaitForAPIReady(SH_SHELL, 0))
        goto GeneralSipCheck;

    hMod = GetModuleHandle(TEXT("aygshell.dll"));
    if (!hMod) 
        goto GeneralSipCheck;
    pfnSHSipInfo = (PFNSHSipInfo) GetProcAddress(hMod, TEXT("SHSipInfo"));
    if (!pfnSHSipInfo)
        goto GeneralSipCheck;

    if ((*pfnSHSipInfo)(SPI_GETSIPINFO, 0, (PVOID) &sSipInfo, 0)) {
        if (sSipInfo.fdwFlags & SIPF_ON) {
            if (!SystemParametersInfo(SPI_GETWORKAREA, 0, &rcScr, 0))
                return FALSE;
            
            // SIP can have minus coordinate. so let's get real display position
            if (!IntersectRect(&rcTmp1, &sSipInfo.rcSipRect, &rcScr)) 
                return FALSE;
            // now check the given RECT is overlapped with SIP
            if (!IntersectRect(&rcTmp2, lprcRect, &rcTmp1))
                return FALSE;
            // now they are overlapped.
            // but need to check that SIP is higher than the given rect. 
            // if it is, there is no meaning to change candidate list position.
            if (rcTmp2.top > sSipInfo.rcSipRect.top)
                return FALSE;
            return TRUE;
        }
    }

GeneralSipCheck:

    if (SipGetInfo(&sSipInfo)) {
        if (sSipInfo.fdwFlags & SIPF_ON) {

            if (!SystemParametersInfo(SPI_GETWORKAREA, 0, &rcScr, 0))
                return FALSE;
            // SIP can have minus coordinate. so let's get real display position
            if (!IntersectRect(&rcTmp1, &sSipInfo.rcSipRect, &rcScr)) 
                return FALSE;
            // now check the given RECT is overlapped with SIP
            if (!IntersectRect(&rcTmp2, lprcRect, &rcTmp1))
                return FALSE;
            // now they are overlapped.
            // but need to check that SIP is higher than the given rect. 
            // if it is, there is no meaning to change candidate list position.
            if (rcTmp2.top > sSipInfo.rcSipRect.top)
                return FALSE;
            return TRUE;
        }
    }
    return FALSE;
}

void UpdateUIPosition(void)
{
    HKEY    hKey;
    DWORD   dwBuf, dwCb;

    GetWorkArea(&rcScreen);
    if ((!EqualRect(&rcOldScrn, &rcScreen)) && (!g_fdwFixedCand))
    {
        g_uiInfo.ptDefPos[STATE_WINDOW].x = rcScreen.right - STATEXSIZE - GetSystemMetrics(SM_CXBORDER)
                - GetSystemMetrics(SM_CXVSCROLL) - GetSystemMetrics(SM_CXHSCROLL);
        g_uiInfo.ptDefPos[STATE_WINDOW].y = rcScreen.bottom - STATEYSIZE;
        g_uiInfo.ptDefPos[COMP_WINDOW].x = g_uiInfo.ptDefPos[STATE_WINDOW].x + STATEXSIZE + GAPX;
        g_uiInfo.ptDefPos[COMP_WINDOW].y = g_uiInfo.ptDefPos[STATE_WINDOW].y + GAPY;
        g_uiInfo.ptDefPos[CAND_WINDOW].x = rcScreen.right - g_nCandSizeX;
        g_uiInfo.ptDefPos[CAND_WINDOW].y = rcScreen.bottom - g_nCandSizeY - STATEYSIZE;
        if (g_uiInfo.ptState.x == -1 && g_uiInfo.ptState.y == -1)
        {
            if (RegOpenKeyEx(HKEY_CURRENT_USER, szIMEKey, 0, KEY_READ , &hKey) == ERROR_SUCCESS)
            {
                dwCb = sizeof(dwBuf);
                if (RegQueryValueEx(hKey, szStatePos, NULL, NULL, (LPBYTE)&dwBuf, &dwCb)
                        == ERROR_SUCCESS)
                {
                    g_uiInfo.ptState.x = HIWORD(dwBuf);
                    g_uiInfo.ptState.y = LOWORD(dwBuf);
                }
                else
                    g_uiInfo.ptState = g_uiInfo.ptDefPos[STATE_WINDOW];
                dwCb = sizeof(dwBuf);
                if (RegQueryValueEx(hKey, szCandPos, NULL, NULL, (LPBYTE)&dwBuf, &dwCb)
                        == ERROR_SUCCESS)
                {
                    g_uiInfo.ptCand.x = HIWORD(dwBuf);
                    g_uiInfo.ptCand.y = LOWORD(dwBuf);
                    if (g_uiInfo.ptCand.x || g_uiInfo.ptCand.y)
                        g_fdwFixedCand=TRUE;
                }
                else
                    g_uiInfo.ptCand = g_uiInfo.ptDefPos[CAND_WINDOW];
                RegCloseKey(hKey);
            }
            else
            {
                g_uiInfo.ptState = g_uiInfo.ptDefPos[STATE_WINDOW];
                g_uiInfo.ptCand = g_uiInfo.ptDefPos[CAND_WINDOW];
            }
        }
        else
        {
            g_uiInfo.ptState.x += rcScreen.left - rcOldScrn.left;
            g_uiInfo.ptState.y += rcScreen.top - rcOldScrn.top;
            g_uiInfo.ptComp.x += rcScreen.left - rcOldScrn.left;
            g_uiInfo.ptComp.y += rcScreen.top - rcOldScrn.top;
            g_uiInfo.ptCand.x += rcScreen.left - rcOldScrn.left;
            g_uiInfo.ptCand.y += rcScreen.top - rcOldScrn.top;
        }
        if (g_uiInfo.ptState.x < rcScreen.left)
            g_uiInfo.ptState.x = rcScreen.left;
        else if (g_uiInfo.ptState.x > rcScreen.right - STATEXSIZE)
            g_uiInfo.ptState.x = rcScreen.right - STATEXSIZE;
        if (g_uiInfo.ptState.y < rcScreen.top)
            g_uiInfo.ptState.y = rcScreen.top;
        else if (g_uiInfo.ptState.y > rcScreen.bottom - STATEYSIZE)
            g_uiInfo.ptState.y = rcScreen.bottom - STATEYSIZE;
        g_uiInfo.ptComp.x = (g_uiInfo.ptState.x + STATEXSIZE + GAPX + COMPSIZE > rcScreen.right)?
                g_uiInfo.ptState.x - GAPX - COMPSIZE: g_uiInfo.ptState.x + STATEXSIZE + GAPX;
        g_uiInfo.ptComp.y = g_uiInfo.ptState.y + GAPY;
        if (g_uiInfo.ptCand.x < rcScreen.left)
            g_uiInfo.ptCand.x = rcScreen.left;
        else if (g_uiInfo.ptCand.x > rcScreen.right - g_nCandSizeX)
            g_uiInfo.ptCand.x = rcScreen.right - g_nCandSizeX;
        if (g_uiInfo.ptCand.y < rcScreen.top)
            g_uiInfo.ptCand.y = rcScreen.top;
        else if (g_uiInfo.ptCand.y > rcScreen.bottom - g_nCandSizeY)
            g_uiInfo.ptCand.y = rcScreen.bottom - g_nCandSizeY;
        rcOldScrn = rcScreen;
    }
}

extern "C"
BOOL InitializeResource(HINSTANCE hInst)
{
    LOGFONT    lf;
    hIMECursor    = LoadCursor(hInst, TEXT("MyHand"));

    hBMClient     = LoadBitmap(hInst, TEXT("Client"));
    hBMHan        = LoadBitmap(hInst, TEXT("Hangul"));
    hBMEng        = LoadBitmap(hInst, TEXT("English"));    // default
    hBMJun        = LoadBitmap(hInst, TEXT("Junja"));
    hBMBan        = LoadBitmap(hInst, TEXT("Banja"));
    hBMChiOn      = LoadBitmap(hInst, TEXT("ChineseOn"));
    hBMChi        = LoadBitmap(hInst, TEXT("ChineseOff"));
    hBMComp       = LoadBitmap(hInst, TEXT("Composition"));
    hBMCand       = LoadBitmap(hInst, TEXT("Candidate"));
    hBMCandNum    = LoadBitmap(hInst, TEXT("CandNumber"));
    hBMCandArr[0] = LoadBitmap(hInst, TEXT("CandArrow1"));
    hBMCandArr[1] = LoadBitmap(hInst, TEXT("CandArrow2"));

    double scaleY;
    #define SCALEY(argY) ((int) ((argY) * scaleY))

    HDC screen = GetDC(0);
    scaleY = GetDeviceCaps(screen, LOGPIXELSY) / 96.0;
    ReleaseDC(0, screen);

    lf.lfWidth = 0;
    lf.lfHeight = SCALEY(-11);
    lf.lfWeight = FW_EXTRALIGHT;
    lf.lfEscapement = 0;
    lf.lfOrientation = 0;
    lf.lfItalic = 0;
    lf.lfUnderline = 0;
    lf.lfStrikeOut = 0;
    lf.lfCharSet = 0;
    lf.lfOutPrecision = OUT_DEFAULT_PRECIS;
    lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
    lf.lfQuality = DEFAULT_QUALITY;
    lf.lfPitchAndFamily = 0;
    StringCchCopy(lf.lfFaceName, sizeof(lf.lfFaceName)/sizeof(lf.lfFaceName[0]), L"Tahoma");
    hFontFix = CreateFontIndirect(&lf);

    ReadHotKey();
    return TRUE;
}

extern "C"
void RemoveResources()
{
    // Remove resources
    DeleteObject(hBMClient);
    DeleteObject(hBMEng);
    DeleteObject(hBMHan);
    DeleteObject(hBMJun);
    DeleteObject(hBMBan);
    
    DeleteObject(hBMChi);
    DeleteObject(hBMChiOn);

    DeleteObject(hBMComp);
    DeleteObject(hBMCand);
    DeleteObject(hBMCandNum);
    DeleteObject(hBMCandArr[0]);
    DeleteObject(hBMCandArr[1]);
    DeleteObject(hIMECursor);
    DeleteObject(hFontFix);
}

extern "C"
BOOL RegisterUIClass(HINSTANCE hInstance)
{
    BOOL        fRet = TRUE;

    WNDCLASS  wc;

    wc.style            = CS_VREDRAW | CS_HREDRAW | CS_IME;
    wc.cbClsExtra       = 0;
    wc.hInstance        = hInstance;
    wc.hCursor          = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon            = NULL;
    wc.lpszMenuName     = (LPCTSTR)NULL;
    wc.hbrBackground    = NULL;


    wc.cbWndExtra       = 8;
    wc.lpfnWndProc      = StateWndProc;
    wc.lpszClassName    = (LPCTSTR)szStateWndName;
    if (!RegisterClass(&wc))
    {
        DEBUGMSG(1, (TEXT("RegisterClassEx() Failed for State Window.\n")));
    }

    wc.cbWndExtra       = 8;
    if (g_fdwVertCand) {
        wc.lpfnWndProc      = VCandWndProc;
    }
    else {
        wc.lpfnWndProc      = CandWndProc;
    }
    wc.lpszClassName    = (LPTSTR)szCandWndName;
    if (!RegisterClass((LPWNDCLASS)&wc))
    {
        DEBUGMSG(1, (TEXT("RegisterClassEx() Failed for Candidate Window.\n")));
    }

    wc.cbWndExtra       = 0;
    wc.lpfnWndProc      = CompWndProc;
    wc.lpszClassName    = (LPTSTR)szCompWndName;
    if (!RegisterClass((LPWNDCLASS)&wc))
    {
        DEBUGMSG(1, (TEXT("RegisterClassEx() Failed for Composition Window.\n")));
    }
    return fRet;
}

extern "C"
BOOL UnregisterUIClass(HINSTANCE hInstance)
{
    BOOL    fRet = TRUE;

    if (!UnregisterClass(szStateWndName, hInstance))
    {
        DEBUGMSG(1, (TEXT("UnregisterClass() Failed for State Window.")));
    }
    if (!UnregisterClass(szCandWndName, hInstance))
    {
        DEBUGMSG(1, (TEXT("UnregisterClass() Failed for Cand Window.")));
    }
#ifdef	EBOOK2_VER
    if (!UnregisterClass(szCompWndName, hInstance))
    {
        DEBUGMSG(1, (TEXT("UnregisterClass() Failed for Comp Window.")));
    }
#endif	EBOOK2_VER
    return fRet;
}


void DrawBitmap(HDC hDC, long xStart, long yStart, HBITMAP hBitmap)
{
    HDC     hMemDC;
    HBITMAP hBMOld;
    BITMAP  bm;
    POINT   pt;

    hMemDC = CreateCompatibleDC(hDC);
    hBMOld = (HBITMAP) SelectObject(hMemDC, hBitmap);
    GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);

    pt.x = bm.bmWidth;
    pt.y = bm.bmHeight;
    BitBlt(hDC, xStart, yStart, pt.x, pt.y, hMemDC, 0, 0, SRCCOPY);
    SelectObject(hMemDC, hBMOld);
    DeleteDC(hMemDC);

    return;
}

// for sate window movement
void ShowWindowBorder()
{
    HDC     hDC;
    HBRUSH  hBrOld;
    int     cxBorder, cyBorder;

    hDC = GetDC(NULL);
    hBrOld = (HBRUSH) SelectObject(hDC, GetStockObject(GRAY_BRUSH));
    cxBorder = 3; 
    cyBorder = 3; 
    PatBlt(hDC, stateWinRect.left, stateWinRect.top, stateWinRect.right-stateWinRect.left-cxBorder, cyBorder, PATINVERT);
    PatBlt(hDC, stateWinRect.right-cxBorder, stateWinRect.top, cxBorder, stateWinRect.bottom-stateWinRect.top-cyBorder, PATINVERT);
    PatBlt(hDC, stateWinRect.right, stateWinRect.bottom-cyBorder, -(stateWinRect.right-stateWinRect.left-cxBorder), cyBorder, PATINVERT);
    PatBlt(hDC, stateWinRect.left, stateWinRect.bottom, cxBorder, -(stateWinRect.bottom-stateWinRect.top-cyBorder), PATINVERT);
    SelectObject(hDC, hBrOld);
    DeleteDC(hDC);

    return;
}


LRESULT CALLBACK StateWndProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
    switch (uMessage)
    {
        case WM_IME_COMPOSITIONFULL:
        case WM_IME_COMPOSITION:
        case WM_IME_CONTROL:
        case WM_IME_NOTIFY:
        case WM_IME_SELECT:
        case WM_IME_SETCONTEXT:
        case WM_IME_STARTCOMPOSITION:
        case WM_IME_ENDCOMPOSITION:
            return TRUE;
            break;
        HANDLE_MSG(hWnd, WM_MOUSEMOVE, State_OnMouseMove);
        HANDLE_MSG(hWnd, WM_LBUTTONDOWN, State_OnLButtonDown);
        HANDLE_MSG(hWnd, WM_LBUTTONUP, State_OnLButtonUp);
        HANDLE_MSG(hWnd, WM_PAINT, State_OnPaint);
        HANDLE_MSG(hWnd, WM_DESTROY, State_OnDestroy);

    default:
        return DefWindowProc(hWnd, uMessage, wParam, lParam);
    }
    return (LRESULT) 0;
}

/*
BOOL State_OnSetCursor(HWND hWnd, HWND hWndCursor, UINT codeHitTest, UINT msg)
{
    
    BOOL    fMovearea=FALSE;

    GetCursorPos(&ptPos);
    ScreenToClient(hWnd, &ptPos);

    if (   PtInRect((LPRECT)&rcHan, ptPos) 
        || PtInRect((LPRECT)&rcChi, ptPos)) {
        SetCursor(LoadCursor(NULL, IDC_ARROW));
    }
    else {
        SetCursor(hIMECursor);
        fMovearea = TRUE;
    }

    switch (msg)
    {
        case WM_LBUTTONDOWN:
            if (fMovearea) {
                fdwUIFlags |= UIF_WNDMOVE;
                GetWindowRect(hWnd, &stateWinRect);
                ShowWindowBorder();
                SetCapture(hWnd);
            } 
            else {
                State_OnLButtonDown(hWnd, 0, ptPos.x, ptPos.y, 0);
            }
            break;

        case WM_LBUTTONUP:
            if ((fdwUIFlags & UIF_CHIPRESS) && PtInRect((LPRECT)&rcChi, ptPos)) {
                    PressHotKey(HanjaConvert);
                    fdwUIFlags &= ~UIF_CHIPRESS;
            }
            break;

    }
    
    return TRUE;
}
*/

void State_OnMouseMove(HWND hWnd, int x, int y, UINT keyFlags)
{
    POINT curPos;
    if (fdwUIFlags & UIF_WNDMOVE) {
        
        ShowWindowBorder();
        stateWinRect.left += x - ptPos.x;
        stateWinRect.top  += y - ptPos.y;
        stateWinRect.right += x - ptPos.x;
        stateWinRect.bottom += y - ptPos.y;
        ShowWindowBorder();
        ptPos.x = x;
        ptPos.y = y;
    }
    else {
        CLEARBUTTONSTATES();
        curPos.x = x; curPos.y = y;
        if ( PtInRect(&rcHan, curPos) && (fdwUIFlags & UIF_HANPRESS) )
            buttonStates[0] = BTS_DOWN;
        else
        if ( PtInRect(&rcChi, curPos) && (fdwUIFlags & UIF_CHIPRESS) )
            buttonStates[1] = BTS_DOWN;

        InvalidateRect(hWnd, NULL, FALSE);
    }
}

void State_OnLButtonDown(HWND hWnd, BOOL fDoubleClick, int x, int y, UINT keyFlags)
{
    POINT pos = {x, y};
    CLEARBUTTONSTATES();
    if (PtInRect(&rcHan, pos))
    {
        fdwUIFlags |= UIF_HANPRESS;
        buttonStates[0] = BTS_DOWN;
        SetCapture(hWnd);
    }
    else if (PtInRect(&rcChi, pos))
    {
    // Not capture when Chinese button pressed. for Word 5.0 and 6.0 compatibility
        fdwUIFlags |= UIF_CHIPRESS;
        buttonStates[1] = BTS_DOWN;
    } 
    else
    {
        fdwUIFlags |= UIF_WNDMOVE;
        ptPos = pos;
        GetWindowRect(hWnd, &stateWinRect);
        ShowWindowBorder();
        SetCapture(hWnd);
    }
    return;
}

void State_OnLButtonUp(HWND hWnd, int x, int y, UINT keyFlags)
{
    RECT            rcWorkArea;
    POINT           curPt;

    ReleaseCapture();
    
    if (fdwUIFlags & UIF_WNDMOVE)
    {
        ShowWindowBorder();

        GetWorkArea(&rcWorkArea);

        if (stateWinRect.left<0) 
            stateWinRect.left = 0;
        if (stateWinRect.left>(rcWorkArea.right-STATEXSIZE)) 
            stateWinRect.left = rcWorkArea.right-STATEXSIZE;
        if (stateWinRect.top<0)
            stateWinRect.top = 0;
        if (stateWinRect.top>(rcWorkArea.bottom-STATEYSIZE))
            stateWinRect.top = rcWorkArea.bottom-STATEYSIZE;
        //
        MoveWindow(hWnd, stateWinRect.left, stateWinRect.top, STATEXSIZE, STATEYSIZE, TRUE);
        g_uiInfo.ptState.x = stateWinRect.left;
        g_uiInfo.ptState.y = stateWinRect.top;
        g_uiInfo.ptComp.x = (g_uiInfo.ptState.x + STATEXSIZE + GAPX + COMPSIZE > rcScreen.right)?
                g_uiInfo.ptState.x - GAPX - COMPSIZE: g_uiInfo.ptState.x + STATEXSIZE + GAPX;
        g_uiInfo.ptComp.y = g_uiInfo.ptState.y + GAPY;
        fdwUIFlags &= ~UIF_WNDMOVE;
    }
    else
    {
        CLEARBUTTONSTATES();
        curPt.x = x; curPt.y = y;
        if ( PtInRect(&rcHan, curPt))
        {
            PressHotKey(KorEngToggle);
        }
        else if ( PtInRect(&rcChi, curPt) )
        {
            PressHotKey(HanjaConvert);
        }
        else
        {
            // button up out of state window
            fdwUIFlags &= ~0x0E;
            InvalidateRect(hWnd, NULL, FALSE);
            ReleaseCapture();
        }
        fdwUIFlags &= ~0x0E;
    }

    return;
}

void State_OnDestroy(HWND hWnd)
{
    if (fdwUIFlags & UIF_WNDMOVE) {
        State_OnLButtonUp(hWnd, 0, 0, 0);
    }

    FORWARD_WM_DESTROY(hWnd, DefWindowProc);
}

typedef struct tagCOLORMAP
{
    COLORREF bgrfrom;
    COLORREF bgrto;
    COLORREF sysColor;
} IME_COLORMAP;

// these are the default colors used to map the dib colors
// to the current system colors

#define BGR_BUTTONTEXT      (RGB(000,000,000))  // black
#define BGR_BUTTONSHADOW    (RGB(128,128,128))  // dark grey
#define BGR_BUTTONFACE      (RGB(192,192,192))  // bright grey
#define BGR_BUTTONHILIGHT   (RGB(255,255,255))  // white
#define BGR_BACKGROUNDSEL   (RGB(255,000,000))  // blue
#define BGR_BACKGROUND      (RGB(255,000,255))  // magenta
#define FlipColor(rgb)      (RGB(GetBValue(rgb), GetGValue(rgb), GetRValue(rgb)))

void GetSysColorsAndMappedBitmap(void)
{
    static DWORD    rgbFace, rgbShadow, rgbHilight, rgbFrame;
    static COLORREF rgbSaveFace     = 0xFFFFFFFFL,
                    rgbSaveShadow   = 0xFFFFFFFFL,
                    rgbSaveHilight  = 0xFFFFFFFFL,
                    rgbSaveFrame    = 0xFFFFFFFFL;

    rgbFace     = GetSysColor(COLOR_BTNFACE);
    rgbShadow   = GetSysColor(COLOR_BTNSHADOW);
    rgbHilight  = GetSysColor(COLOR_BTNHIGHLIGHT);
    rgbFrame    = GetSysColor(COLOR_WINDOWFRAME);

    if (rgbSaveFace != rgbFace || rgbSaveShadow != rgbShadow
            || rgbSaveHilight != rgbHilight || rgbSaveFrame != rgbFrame)
    {
        rgbSaveFace     = rgbFace;
        rgbSaveShadow   = rgbShadow;
        rgbSaveHilight  = rgbHilight;
        rgbSaveFrame    = rgbFrame;

        DeleteObject(hBMClient);
        DeleteObject(hBMEng);
        DeleteObject(hBMHan);
        DeleteObject(hBMJun);
        DeleteObject(hBMBan);

        DeleteObject(hBMChi);
        DeleteObject(hBMChiOn);

        DeleteObject(hBMComp);
        DeleteObject(hBMCand);
        DeleteObject(hBMCandNum);
        DeleteObject(hBMCandArr[0]);
        DeleteObject(hBMCandArr[1]);

        hBMClient     = LoadBitmap(g_hInst, TEXT("Client"));
        hBMHan        = LoadBitmap(g_hInst, TEXT("Hangul"));
        hBMEng        = LoadBitmap(g_hInst, TEXT("English"));    // default
        hBMJun        = LoadBitmap(g_hInst, TEXT("Junja"));
        hBMBan        = LoadBitmap(g_hInst, TEXT("Banja"));
        hBMChiOn      = LoadBitmap(g_hInst, TEXT("ChineseOn"));
        hBMChi        = LoadBitmap(g_hInst, TEXT("ChineseOff"));
        hBMComp       = LoadBitmap(g_hInst, TEXT("Composition"));
        hBMCand       = LoadBitmap(g_hInst, TEXT("Candidate"));
        hBMCandNum    = LoadBitmap(g_hInst, TEXT("CandNumber"));
        hBMCandArr[0] = LoadBitmap(g_hInst, TEXT("CandArrow1"));
        hBMCandArr[1] = LoadBitmap(g_hInst, TEXT("CandArrow2"));
    
    }
}


void State_OnPaint(HWND hWnd)
{
    HDC             hDC, hClientMemDC, hButtonMemDC;
    HBITMAP         hBMStateWin, hBMClientOld, hBMButtonOld;
    PAINTSTRUCT     ps;
    
    hDC = BeginPaint(hWnd, &ps);

    hClientMemDC = CreateCompatibleDC(hDC);
    hBMStateWin  = CreateCompatibleBitmap(hDC, STATEXSIZE, STATEYSIZE);
    hBMClientOld = (HBITMAP) SelectObject(hClientMemDC, hBMStateWin);

    hButtonMemDC = CreateCompatibleDC(hDC);
    hBMButtonOld = (HBITMAP) SelectObject(hButtonMemDC, hBMClient);
    BitBlt(hClientMemDC, 0, 0, STATEXSIZE, STATEYSIZE, hButtonMemDC, 0, 0, SRCCOPY);


    if ( buttonStates[0] || (g_dwStateFlag & IME_CMODE_HANGEUL) ) {
        hBMButtonOld = (HBITMAP) SelectObject(hButtonMemDC, hBMHan);
        BitBlt(hClientMemDC, rcHan.left, rcHan.top, BUTTONSIZEX, BUTTONSIZEY, 
               hButtonMemDC, 0, 0, SRCCOPY);
        SelectObject(hButtonMemDC, hBMButtonOld);
    }
    else {
        hBMButtonOld = (HBITMAP) SelectObject(hButtonMemDC, hBMEng);
        BitBlt(hClientMemDC, rcHan.left, rcHan.top, BUTTONSIZEX, BUTTONSIZEY,
               hButtonMemDC, 0, 0, SRCCOPY);
        SelectObject(hButtonMemDC, hBMButtonOld);
    }

    if ( buttonStates[1] || g_dwStateFlag & IME_CMODE_HANJACONVERT ) {
        hBMButtonOld = (HBITMAP) SelectObject(hButtonMemDC, hBMChiOn);
        BitBlt(hClientMemDC, rcChi.left, rcChi.top, BUTTONSIZEX, BUTTONSIZEY, 
                hButtonMemDC, 0, 0, SRCCOPY);
        SelectObject(hButtonMemDC, hBMButtonOld);
    }
    else {
        hBMButtonOld = (HBITMAP) SelectObject(hButtonMemDC, hBMChi);
        BitBlt(hClientMemDC, rcChi.left, rcChi.top, BUTTONSIZEX, BUTTONSIZEY, 
               hButtonMemDC, 0, 0, SRCCOPY);
        SelectObject(hButtonMemDC, hBMButtonOld);
    }


    BitBlt(hDC, 0, 0, STATEXSIZE, STATEYSIZE, hClientMemDC, 0, 0, SRCCOPY);

    SelectObject(hClientMemDC, hBMClientOld);
    DeleteObject(hButtonMemDC);
    DeleteObject(hClientMemDC);
    DeleteObject(hBMStateWin);


    EndPaint(hWnd, &ps);
    return;
}

LRESULT CALLBACK CompWndProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
    switch (uMessage)
    {
        case WM_IME_COMPOSITIONFULL:
        case WM_IME_COMPOSITION:
        case WM_IME_CONTROL:
        case WM_IME_NOTIFY:
        case WM_IME_SELECT:
        case WM_IME_SETCONTEXT:
        case WM_IME_STARTCOMPOSITION:
        case WM_IME_ENDCOMPOSITION:
            break;
        HANDLE_MSG(hWnd, WM_PAINT, Comp_OnPaint);
    }
    return DefWindowProc(hWnd, uMessage, wParam, lParam);
}


void Comp_OnPaint(HWND hWnd)
{
    HDC                 hDC;
    PAINTSTRUCT         ps;
    int                 iSaveBkMode;
    RECT                rect;
    
    hDC = BeginPaint(hWnd, &ps);

    if (g_szCompStr[0])
    {
        DrawBitmap(hDC, 0, 0, hBMComp);
        iSaveBkMode = SetBkMode(hDC, TRANSPARENT);
        GetClientRect(hWnd,&rect);
        DrawText(hDC, g_szCompStr, 1, &rect, DT_CENTER | DT_VCENTER); 
        SetBkMode(hDC, iSaveBkMode);
    }
    EndPaint(hWnd, &ps);
}


LRESULT CALLBACK CandWndProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
    switch (uMessage)
    {
        case WM_IME_COMPOSITIONFULL:
        case WM_IME_COMPOSITION:
        case WM_IME_CONTROL:
        case WM_IME_NOTIFY:
        case WM_IME_SELECT:
        case WM_IME_SETCONTEXT:
        case WM_IME_STARTCOMPOSITION:
        case WM_IME_ENDCOMPOSITION:
            return TRUE;
            break;
        case WM_SETTINGCHANGE:
            if ((wParam == SETTINGCHANGE_RESET) && IsWindowVisible(hWnd)) {
                PressHotKey(CandESC);
            }
            break;
            
        HANDLE_MSG(hWnd, WM_LBUTTONDOWN, Cand_OnLButtonDown);
        HANDLE_MSG(hWnd, WM_LBUTTONUP, Cand_OnLButtonUp);
        HANDLE_MSG(hWnd, WM_PAINT, Cand_OnPaint);
    }
    return DefWindowProc(hWnd, uMessage, wParam, lParam);
}

static void Cand_OnSetFocus(HWND hwnd, HWND hwndOldFocus)
{
    SetFocus(hwndOldFocus);
}

void Cand_OnLButtonDown(HWND hWnd, BOOL fDoubleClick, int x, int y, UINT keyFlags)
{
    POINT pos = {x, y};

    if (PtInRect(&rcCandCli, pos))
    {
        if (!PtInRect(&rcLArrow, pos)
                && !PtInRect(&rcRArrow, pos)
                && !PtInRect(&rcBtn[0], pos)
                && !PtInRect(&rcBtn[1], pos)
                && !PtInRect(&rcBtn[2], pos)
                && !PtInRect(&rcBtn[3], pos)
                && !PtInRect(&rcBtn[4], pos)
                && !PtInRect(&rcBtn[5], pos)
                && !PtInRect(&rcBtn[6], pos)
                && !PtInRect(&rcBtn[7], pos)
                && !PtInRect(&rcBtn[8], pos))
            MessageBeep(MB_ICONEXCLAMATION);
    }
}

void Cand_OnLButtonUp(HWND hWnd, int x, int y, UINT keyFlags)
{

    POINT pos = {x, y};
    int iLoop;

    if (PtInRect(&rcLArrow, pos))
    {
        PressHotKey(CandPrevPage);
    }
    else if (PtInRect(&rcRArrow, pos))
    {
        PressHotKey(CandNextPage);
    }
    else
    {
        for (iLoop = 0; iLoop < 9; iLoop++)
            if (PtInRect(&rcBtn[iLoop], pos))
            {    
                keybd_event((BYTE)(iLoop + '1'), 0, 0, 0);
                keybd_event((BYTE)(iLoop + '1'), 0, KEYEVENTF_KEYUP, 0);
                break;
            }
    }
}


BOOL Cand_OnSetCursor(HWND hWnd, HWND hWndCursor, UINT codeHitTest, UINT msg)
{
    int iLoop;

    SetCursor(hIMECursor);

    switch (msg)
    {
        case WM_LBUTTONDOWN:
            GetCursorPos(&ptPos);
            ScreenToClient(hWnd, &ptPos);
            if (PtInRect(&rcCandCli, ptPos))
            {
                if (!PtInRect(&rcLArrow, ptPos)
                        && !PtInRect(&rcRArrow, ptPos)
                        && !PtInRect(&rcBtn[0], ptPos)
                        && !PtInRect(&rcBtn[1], ptPos)
                        && !PtInRect(&rcBtn[2], ptPos)
                        && !PtInRect(&rcBtn[3], ptPos)
                        && !PtInRect(&rcBtn[4], ptPos)
                        && !PtInRect(&rcBtn[5], ptPos)
                        && !PtInRect(&rcBtn[6], ptPos)
                        && !PtInRect(&rcBtn[7], ptPos)
                        && !PtInRect(&rcBtn[8], ptPos))
                    MessageBeep(MB_ICONEXCLAMATION);
            }
            break;

        case WM_LBUTTONUP:
            GetCursorPos(&ptPos);
            ScreenToClient(hWnd, &ptPos);
            if (PtInRect(&rcLArrow, ptPos))
            {
                keybd_event(VK_LEFT, 0, 0, 0);
                keybd_event(VK_LEFT, 0, KEYEVENTF_KEYUP, 0);
            }
            else if (PtInRect(&rcRArrow, ptPos))
            {
                keybd_event(VK_RIGHT, 0, 0, 0);
                keybd_event(VK_RIGHT, 0, KEYEVENTF_KEYUP, 0);
            }
            else
            {
                for (iLoop = 0; iLoop < 9; iLoop++)
                    if (PtInRect(&rcBtn[iLoop], ptPos))
                    {    
                        keybd_event((BYTE)(iLoop + '1'), 0, 0, 0);
                        keybd_event((BYTE)(iLoop + '1'), 0, KEYEVENTF_KEYUP, 0);
                        break;
                    }
            }
            break;
    }    
    return TRUE;
}


void Cand_OnPaint(HWND hWnd)
{
    HDC             hDC;
    LPCTSTR         lpCandStr;
    PAINTSTRUCT     ps;
    DWORD           iLoop, iStart;
    int             iSaveBkMode;
    RECT            rect;


    hDC = BeginPaint(hWnd, &ps);
    if ( g_lpCandList && g_lpCandList->dwCount )
    {
        DrawBitmap(hDC, 0, 0, hBMCand);
        iSaveBkMode = SetBkMode(hDC, TRANSPARENT);
        iStart = (g_lpCandList->dwSelection / g_lpCandList->dwPageSize) * g_lpCandList->dwPageSize;
        for (iLoop = 0; iLoop < 9 && iStart+iLoop < g_lpCandList->dwCount; iLoop++)
        {
            lpCandStr = (LPCTSTR) ((LPSTR)g_lpCandList + g_lpCandList->dwOffset[iStart + iLoop]);
            rect.left = rcBtn[iLoop].left + 2;
            rect.right = rcBtn[iLoop].right + 2;
            rect.top = rcBtn[iLoop].top;
            rect.bottom = rcBtn[iLoop].bottom;
            DrawText(hDC, lpCandStr, 1, &rect, DT_CENTER | DT_VCENTER); 
        }
        SetBkMode(hDC, iSaveBkMode);
        for (; iLoop < 9; iLoop++)
            DrawBitmap(hDC, rcBtn[iLoop].left + 1, rcBtn[iLoop].top + 6, hBMCandNum);
        if (iStart)
            DrawBitmap(hDC, 6, 8, hBMCandArr[0]);
        if (iStart + 9 < g_lpCandList->dwCount)
            DrawBitmap(hDC, 228, 8, hBMCandArr[1]);
    }
    EndPaint(hWnd, &ps);
}

LRESULT CALLBACK VCandWndProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
    switch (uMessage)
    {
        case WM_IME_COMPOSITIONFULL:
        case WM_IME_COMPOSITION:
        case WM_IME_CONTROL:
        case WM_IME_NOTIFY:
        case WM_IME_SELECT:
        case WM_IME_SETCONTEXT:
        case WM_IME_STARTCOMPOSITION:
        case WM_IME_ENDCOMPOSITION:
            return TRUE;
            break;
        case WM_SETTINGCHANGE:
            if ((wParam == SETTINGCHANGE_RESET) && IsWindowVisible(hWnd)) {
                RETAILMSG(1,(TEXT("VCandWndProc() Got WM_SETTINGCHANGE, SETTINGCHANGE_RESET\n")));
                PressHotKey(CandESC);
            }
            break;
            
        HANDLE_MSG(hWnd, WM_LBUTTONDOWN, VCand_OnLButtonDown);
        HANDLE_MSG(hWnd, WM_LBUTTONUP, VCand_OnLButtonUp);
        HANDLE_MSG(hWnd, WM_MOUSEMOVE, VCand_OnMouseMove);
        HANDLE_MSG(hWnd, WM_VSCROLL, VCand_OnVScroll);
        HANDLE_MSG(hWnd, WM_PAINT, VCand_OnPaint);
    }
	RETAILMSG(1, (_T("\tVCandWndProc() : uMessage(0x%X) wParam(0x%X), lParam(0x%X)\r\n"),
		uMessage, wParam, lParam));
    return DefWindowProc(hWnd, uMessage, wParam, lParam);
}

void VCand_OnLButtonDown(HWND hWnd, BOOL fDoubleClick, int x, int y, UINT keyFlags)
{
    POINT pos = {x, y};
    int i;

    SetCapture(hWnd);
    for (i = 0; i < 5; i++) {
        if (PtInRect((LPRECT)&rcVIndex[i], pos) || PtInRect((LPRECT)&rcVButton[i], pos)) {
            nSelect = i;
            break;
        }
    }
    if (i < 5) {
        InvalidateRect( hWnd, NULL, TRUE);
    }
    else
        ReleaseCapture();
}

void VCand_OnMouseMove(HWND hWnd, int x, int y, UINT keyFlags)
{
    POINT pos = {x, y};
    int i;
    BOOL bRedraw = FALSE;

    if (nSelect >= 0 && nSelect < 5) {
        for (i = 0; i < 5; i++) {
            if (PtInRect((LPRECT)&rcVIndex[i], pos) || PtInRect((LPRECT)&rcVButton[i], pos)) {
                if (i != nSelect) {
                    nSelect = i;
                    bRedraw = TRUE;
                }
                break;
            }
        }
    }
    if (bRedraw) {
        InvalidateRect( hWnd, NULL, TRUE);
    }
}

void VCand_OnLButtonUp(HWND hWnd, int x, int y, UINT keyFlags)
{
    POINT pos = {x, y};

    ReleaseCapture();
    keybd_event((BYTE)(nSelect + '1'), 0, 0, 0);
    keybd_event((BYTE)(nSelect + '1'), 0, KEYEVENTF_KEYUP, 0);
    nSelect = -1;
    InvalidateRect( hWnd, NULL, TRUE);
    
}

void VCand_OnVScroll(HWND hWnd, HWND hScrollbar, UINT nScrollCode, short int nPos)
{
    HWND hMainWnd = (HWND) GetWindowLong(hWnd, GWL_USERDATA);
    if (hScrollbar && hMainWnd) 
    {
        if (nScrollCode != SB_ENDSCROLL) 
        {
            PostMessage(hMainWnd, WM_IMEUI_REQ_CHANGECAND, nScrollCode, nPos);
            RETAILMSG(1,(TEXT("PostMessage - WM_IMEUI_REQ_CHANGECAND nPos = %d\n"), nPos));
        }
    }
}

void VCand_OnPaint(HWND hWnd)
{
    HDC             hDC;
    LPCTSTR         lpCandStr;
    PAINTSTRUCT     ps;
    HFONT           hOldFont;
    DWORD           iLoop;
    RECT            rect;
    TCHAR           szItem[] = TEXT("12345");
    TCHAR           szPage[10];
    COLORREF        oldref, oldref2;
    BOOL            flag=FALSE;

    hDC = BeginPaint(hWnd, &ps);
    if ( g_lpCandList && g_lpCandList->dwCount )
    {
        Rectangle(hDC, 0, 0, g_nCandSizeX, g_nCandSizeY);
        oldref = SetTextColor(hDC, GetSysColor(COLOR_WINDOWTEXT));
        oldref2 = SetBkColor(hDC, GetSysColor(COLOR_WINDOW));
        for (iLoop = 0; iLoop < g_lpCandList->dwPageSize && g_lpCandList->dwPageStart+iLoop < g_lpCandList->dwCount; iLoop++)
        {
            lpCandStr = (LPCTSTR) ((LPSTR)g_lpCandList + g_lpCandList->dwOffset[g_lpCandList->dwPageStart + iLoop]);
            if (nSelect >= 0) {
                if (iLoop == (DWORD)nSelect ) {
                    SetTextColor(hDC, GetSysColor(COLOR_HIGHLIGHTTEXT));
                    SetBkColor(hDC, GetSysColor(COLOR_HIGHLIGHT));
                    flag = TRUE;
                }
            }
            else if (g_lpCandList->dwPageStart+iLoop == g_lpCandList->dwSelection ) {
                SetTextColor(hDC, GetSysColor(COLOR_HIGHLIGHTTEXT));
                SetBkColor(hDC, GetSysColor(COLOR_HIGHLIGHT));
                flag = TRUE;
            }
            else {
                SetTextColor(hDC, GetSysColor(COLOR_WINDOWTEXT));
                SetBkColor(hDC, GetSysColor(COLOR_WINDOW));
            }
            
#define MARGIN_X    2
#define MARGIN_Y    1

            int margin;
            if (g_fdwAutoCandAccel && IsSIPOn()) {
                rect = rcVButton[iLoop];
                rect.top++; rect.left++;
                rect.right--; rect.bottom--;
                margin = ((rect.right - rect.left) - g_sizeUnit.cx)/2;
                ExtTextOut(hDC, rcVButton[iLoop].left+margin, rcVButton[iLoop].top+MARGIN_Y, ETO_OPAQUE, &rect, lpCandStr, 1, NULL);
            }
            else {
                rect = rcVIndex[iLoop];
                rect.top++; rect.left++; rect.bottom--;
                ExtTextOut(hDC, rcVIndex[iLoop].left+MARGIN_X*2, rcVIndex[iLoop].top+MARGIN_Y, ETO_OPAQUE, &rect, &szItem[iLoop], 1, NULL);
                rect = rcVButton[iLoop];
                rect.top++;
                rect.right--; rect.bottom--;
                margin = ((rect.right - rect.left) - g_sizeUnit.cx)/2;
                ExtTextOut(hDC, rcVButton[iLoop].left + margin, rcVButton[iLoop].top+MARGIN_Y, ETO_OPAQUE, &rect, lpCandStr, 1, NULL);
            }
            if (flag) {
                SetTextColor(hDC, oldref);
                SetBkColor(hDC, oldref2);
                flag = FALSE;
            }
        }
        if (iLoop < g_lpCandList->dwPageSize) {
            if (g_fdwAutoCandAccel && IsSIPOn()) {
                rect.left = rcVButton[iLoop].left + 1; 
                rect.top = rcVButton[iLoop].top;
            }
            else {
                rect.left = rcVIndex[iLoop].left + 1; 
                rect.top = rcVIndex[iLoop].top;
            }
            rect.right = g_nCandSizeX-1; 
            rect.bottom = g_nCandSizeY-1;
            ExtTextOut(hDC, 0, 0, ETO_OPAQUE, &rect, NULL, 0, NULL);
        }
        StringCchPrintf(szPage, sizeof(szPage)/sizeof(szPage[0]), L"%d/%d", g_lpCandList->dwSelection + 1, g_lpCandList->dwCount);
        hOldFont = (HFONT) SelectObject(hDC, hFontFix);
        SetTextColor(hDC, GetSysColor(COLOR_BTNTEXT));
        SetBkColor(hDC, GetSysColor(COLOR_BTNFACE));
           
        HBRUSH hbr = CreateSolidBrush(GetSysColor(COLOR_BTNFACE));
        HBRUSH hbrold = NULL;
        if (hbr) {
            hbrold = (HBRUSH) SelectObject(hDC, hbr);
        }
        rect = rcPage;
        Rectangle(hDC, rect.left, rect.top, rect.right, rect.bottom);
        if (hbrold) {
            SelectObject(hDC, hbrold);
        }
        if (hbr)
            DeleteObject(hbr);
        rect.left++; rect.top++; rect.right--; rect.bottom--;
        DrawText(hDC, szPage, -1, &rect, DT_CENTER | DT_NOPREFIX);

        SetTextColor(hDC, oldref);
        SetBkColor(hDC, oldref2);
        SelectObject(hDC, hOldFont);
    }
    EndPaint(hWnd, &ps);
}

void GetCandPos(HWND hWnd, DWORD dwFlag, const RECT *pRect, POINT &pt)
{
    RECT rcTmp;
    RECT rcScr;
    BOOL fIsThereSip = FALSE;

    GetWorkArea(&rcScr);
    
    switch (dwFlag) {
    case CFS_CANDIDATEPOS:
        if (pt.x < rcScr.left)
            pt.x = rcScr.left;
        else if (pt.x > rcScr.right - g_nCandSizeX)
            pt.x = rcScr.right - g_nCandSizeX;
        if (pt.y < rcScr.top)
            pt.y = rcScr.top;
        else if (pt.y > rcScr.bottom - g_nCandSizeY)
            pt.y = rcScr.bottom - g_nCandSizeY;
        break;
    case CFS_EXCLUDE:
        rcTmp.left = pt.x;
        rcTmp.top = pt.y;
        rcTmp.right = pt.x + g_nCandSizeX;
        rcTmp.bottom = pt.y + g_nCandSizeY;
        if (CheckRectForSIP(&rcTmp))
             fIsThereSip = TRUE;
        if (pt.x < rcScr.left)
            pt.x = rcScr.left;
        else if (pt.x > rcScr.right - g_nCandSizeX)
            pt.x = rcScr.right - g_nCandSizeX;
        if (pt.y < rcScr.top)
            pt.y = rcScr.top;
        else if (pt.y > rcScr.bottom - g_nCandSizeY)
            pt.y = rcScr.bottom - g_nCandSizeY;

        rcTmp.left = pt.x;
        rcTmp.top = pt.y;
        rcTmp.right = pt.x + g_nCandSizeX;
        rcTmp.bottom = pt.y + g_nCandSizeY;

        if (IntersectRect(&rcTmp, &rcTmp, pRect) || fIsThereSip)
        {
            if ((pRect->bottom < (rcScr.bottom - g_nCandSizeY)) && !fIsThereSip) {
                pt.y = pRect->bottom;
            }
            else {
                if ((pRect->top - g_nCandSizeY) >= rcScr.top)
                    pt.y = pRect->top - g_nCandSizeY;
                else
                    pt.y = rcScr.top;
            }
        }

        break;
    default:
        pt = g_uiInfo.ptCand;
    }
}
