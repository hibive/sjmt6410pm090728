//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
// kimeui.cpp : Implementation of DLL Exports.
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//


// Note: Proxy/Stub Information
//		To build a separate proxy/stub DLL, 
//		run nmake -f kimeuips.mk in the project directory.

#include "stdafx.h"
#include "resource.h"
#include "initguid.h"
#include "kimeui.h"
#include "KoreanImeUI.h"
#include "uiInfo.h"

CComModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
OBJECT_ENTRY(CLSID_KoreanImeUI, CKoreanImeUI)
END_OBJECT_MAP()

/////////////////////////////////////////////////////////////////////////////
// DLL Entry Point
HINSTANCE g_hInst;
extern "C" BOOL InitializeResource(HINSTANCE hInst);
extern "C" void RemoveResources();
extern "C" BOOL RegisterUIClass(HANDLE hInstance);
extern "C" BOOL UnregisterUIClass(HANDLE hInstance);
extern "C" BOOL CreateUIWnds();

LPVOID g_lpSharedUIPos=NULL;
#define g_uiInfo	(*(UIINFO *)g_lpSharedUIPos)
#define rcScreen	(*(LPRECT)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)))
#define rcOldScrn	(*(LPRECT)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)+sizeof(RECT)))
#define g_fdwFixedCand	(*(LPDWORD)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)+sizeof(RECT)+sizeof(RECT)))
#define g_fdwVertCand	(*(LPDWORD)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)+sizeof(RECT)+sizeof(RECT)+sizeof(DWORD)))
#define g_fdwAutoCandAccel	(*(LPDWORD)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)+sizeof(RECT)+sizeof(RECT)+sizeof(DWORD)*2))

extern const TCHAR g_szIMEUIKey[];
const TCHAR g_szVertCandUI[]=TEXT("Vertical");   // dword: 0 or 1   default : 0
const TCHAR g_szAutoCandAccel[]=TEXT("AutoCandAccel");   // dword: 0 or 1   default : 0

extern "C"
BOOL WINAPI DllMain(HANDLE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
	static HANDLE hMapFile = NULL;
	static DWORD dwCount = 0;
	BOOL fInit;

	g_hInst = (HINSTANCE) hInstance;
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls((HMODULE)hInstance);
		 
		hMapFile = CreateFileMapping((HANDLE)-1, (LPSECURITY_ATTRIBUTES) NULL, PAGE_READWRITE, (DWORD) 0, (DWORD) (sizeof(UIINFO)+sizeof(RECT)*2 + sizeof(DWORD)*3), TEXT("ImeUIPos") );
		fInit = (GetLastError() != ERROR_ALREADY_EXISTS);
		g_lpSharedUIPos = (HANDLE *)MapViewOfFile( hMapFile, FILE_MAP_WRITE, (DWORD) 0, (DWORD) 0, (DWORD) (sizeof(UIINFO)+sizeof(RECT)*2 + sizeof(DWORD)*3));
		if (fInit) {
			g_uiInfo.ptDefPos[0].x = g_uiInfo.ptDefPos[1].x = g_uiInfo.ptDefPos[2].x = g_uiInfo.ptState.x = g_uiInfo.ptComp.x = g_uiInfo.ptCand.x = -1;
			g_uiInfo.ptDefPos[0].y = g_uiInfo.ptDefPos[1].y = g_uiInfo.ptDefPos[2].y = g_uiInfo.ptState.y = g_uiInfo.ptComp.y = g_uiInfo.ptCand.y = -1;
			g_fdwFixedCand=FALSE;
			
			g_fdwVertCand= 0;
			HKEY hKey;
			DWORD dwSize = sizeof(DWORD);
			if (RegOpenKeyEx(HKEY_CURRENT_USER, g_szIMEUIKey, 0, 0 , &hKey) == ERROR_SUCCESS) {
				RegQueryValueEx(hKey, g_szVertCandUI, NULL, NULL, (LPBYTE)&g_fdwVertCand, &dwSize);
				RegQueryValueEx(hKey, g_szAutoCandAccel, NULL, NULL, (LPBYTE)&g_fdwAutoCandAccel, &dwSize);
			}

		}
		if (dwCount == 0) {
			InitializeResource((HINSTANCE) hInstance);
			RegisterUIClass(hInstance);
		}
		dwCount++;

		_Module.Init(ObjectMap, (HINSTANCE)hInstance);
#ifndef UNDER_CE
		DisableThreadLibraryCalls((HINSTANCE)hInstance);
#endif
	}
	else if (dwReason == DLL_PROCESS_DETACH) {
		--dwCount;
		UnmapViewOfFile( (LPCVOID) g_lpSharedUIPos);
		CloseHandle(hMapFile);
		if (dwCount == 0) {
			UnregisterUIClass(hInstance);
			RemoveResources();
		}
		_Module.Term();
	}
	return TRUE;    // ok
}

/////////////////////////////////////////////////////////////////////////////
// Used to determine whether the DLL can be unloaded by OLE

STDAPI DllCanUnloadNow(void)
{
	return (_Module.GetLockCount()==0) ? S_OK : S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Returns a class factory to create an object of the requested type

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
	return _Module.GetClassObject(rclsid, riid, ppv);
}

/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
	// registers object, typelib and all interfaces in typelib
	return _Module.RegisterServer(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
	_Module.UnregisterServer();
	return S_OK;
}

