//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//

#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0286 */
/* at Fri May 23 15:40:17 2003
 */
/* Compiler settings for kimeui.idl:
    Os (OptLev=s), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __kimeui_h__
#define __kimeui_h__

/* Forward Declarations */ 

#ifndef __KoreanImeUI_FWD_DEFINED__
#define __KoreanImeUI_FWD_DEFINED__

#ifdef __cplusplus
typedef class KoreanImeUI KoreanImeUI;
#else
typedef struct KoreanImeUI KoreanImeUI;
#endif /* __cplusplus */

#endif 	/* __KoreanImeUI_FWD_DEFINED__ */


#ifndef __IKoreanImeUI_FWD_DEFINED__
#define __IKoreanImeUI_FWD_DEFINED__
typedef interface IKoreanImeUI IKoreanImeUI;
#endif 	/* __IKoreanImeUI_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __KIMEUILib_LIBRARY_DEFINED__
#define __KIMEUILib_LIBRARY_DEFINED__

/* library KIMEUILib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_KIMEUILib;

EXTERN_C const CLSID CLSID_KoreanImeUI;

#ifdef __cplusplus

class DECLSPEC_UUID("E9FBDEF9-A48D-4C68-9D96-E4EEB922938A")
KoreanImeUI;
#endif
#endif /* __KIMEUILib_LIBRARY_DEFINED__ */

/* interface __MIDL_itf_kimeui_0000 */
/* [local] */ 

typedef struct tagIMEUISPEC
    {
    boolean Status;
    boolean Cand;
    boolean Comp;
    boolean Full;
    }	IMEUISPEC;

typedef struct tagIMEUISPEC __RPC_FAR *LPIMEUISPEC;



extern RPC_IF_HANDLE __MIDL_itf_kimeui_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_kimeui_0000_v0_0_s_ifspec;

#ifndef __IKoreanImeUI_INTERFACE_DEFINED__
#define __IKoreanImeUI_INTERFACE_DEFINED__

/* interface IKoreanImeUI */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IKoreanImeUI;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("0DFBDDC0-C8D2-44C3-8C72-DC994C7F383A")
    IKoreanImeUI : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetStatusWndPos( 
            /* [out] */ long __RPC_FAR *px,
            /* [out] */ long __RPC_FAR *py) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetCompWndPos( 
            /* [out] */ long __RPC_FAR *px,
            /* [out] */ long __RPC_FAR *py) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetCandWndPos( 
            /* [out] */ long __RPC_FAR *px,
            /* [out] */ long __RPC_FAR *py) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE ShowHideStatusWnd( 
            /* [in] */ int bShow) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE SetStatusData( 
            /* [in] */ DWORD dwState) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE RedrawStatusWnd( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE SetStatusWndPos( 
            /* [in] */ long x,
            /* [in] */ long y) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE ShowHideCandWnd( 
            /* [in] */ int bShow) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE SetCandData( 
            /* [in] */ DWORD dwSize,
            /* [size_is][in] */ BYTE __RPC_FAR *lpCandList) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE RedrawCandWnd( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE SetCandWndPos( 
            /* [in] */ DWORD dwFlag,
            /* [in] */ RECT __RPC_FAR *pRect,
            /* [in] */ long x,
            /* [in] */ long y) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE ShowHideCompWnd( 
            /* [in] */ int bShow) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE SetCompData( 
            /* [in] */ DWORD dwCompLen,
            /* [size_is][in] */ WCHAR __RPC_FAR *lpCompStr) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE RedrawCompWnd( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE SetCompWndPos( 
            /* [in] */ long x,
            /* [in] */ long y) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE InitializeUIWindows( 
            /* [defaultvalue][in] */ HWND hMainWnd = 0) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE UninitializeUIWindows( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetCompositionFont( 
            /* [in] */ DWORD dwSize,
            /* [size_is][out] */ BYTE __RPC_FAR *pLogFont) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IKoreanImeUIVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IKoreanImeUI __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IKoreanImeUI __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetStatusWndPos )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [out] */ long __RPC_FAR *px,
            /* [out] */ long __RPC_FAR *py);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCompWndPos )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [out] */ long __RPC_FAR *px,
            /* [out] */ long __RPC_FAR *py);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCandWndPos )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [out] */ long __RPC_FAR *px,
            /* [out] */ long __RPC_FAR *py);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShowHideStatusWnd )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ int bShow);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetStatusData )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ DWORD dwState);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RedrawStatusWnd )( 
            IKoreanImeUI __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetStatusWndPos )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ long x,
            /* [in] */ long y);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShowHideCandWnd )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ int bShow);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCandData )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ DWORD dwSize,
            /* [size_is][in] */ BYTE __RPC_FAR *lpCandList);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RedrawCandWnd )( 
            IKoreanImeUI __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCandWndPos )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ DWORD dwFlag,
            /* [in] */ RECT __RPC_FAR *pRect,
            /* [in] */ long x,
            /* [in] */ long y);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShowHideCompWnd )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ int bShow);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCompData )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ DWORD dwCompLen,
            /* [size_is][in] */ WCHAR __RPC_FAR *lpCompStr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RedrawCompWnd )( 
            IKoreanImeUI __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCompWndPos )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ long x,
            /* [in] */ long y);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *InitializeUIWindows )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [defaultvalue][in] */ HWND hMainWnd);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UninitializeUIWindows )( 
            IKoreanImeUI __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCompositionFont )( 
            IKoreanImeUI __RPC_FAR * This,
            /* [in] */ DWORD dwSize,
            /* [size_is][out] */ BYTE __RPC_FAR *pLogFont);
        
        END_INTERFACE
    } IKoreanImeUIVtbl;

    interface IKoreanImeUI
    {
        CONST_VTBL struct IKoreanImeUIVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IKoreanImeUI_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IKoreanImeUI_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IKoreanImeUI_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IKoreanImeUI_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IKoreanImeUI_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IKoreanImeUI_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IKoreanImeUI_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IKoreanImeUI_GetStatusWndPos(This,px,py)	\
    (This)->lpVtbl -> GetStatusWndPos(This,px,py)

#define IKoreanImeUI_GetCompWndPos(This,px,py)	\
    (This)->lpVtbl -> GetCompWndPos(This,px,py)

#define IKoreanImeUI_GetCandWndPos(This,px,py)	\
    (This)->lpVtbl -> GetCandWndPos(This,px,py)

#define IKoreanImeUI_ShowHideStatusWnd(This,bShow)	\
    (This)->lpVtbl -> ShowHideStatusWnd(This,bShow)

#define IKoreanImeUI_SetStatusData(This,dwState)	\
    (This)->lpVtbl -> SetStatusData(This,dwState)

#define IKoreanImeUI_RedrawStatusWnd(This)	\
    (This)->lpVtbl -> RedrawStatusWnd(This)

#define IKoreanImeUI_SetStatusWndPos(This,x,y)	\
    (This)->lpVtbl -> SetStatusWndPos(This,x,y)

#define IKoreanImeUI_ShowHideCandWnd(This,bShow)	\
    (This)->lpVtbl -> ShowHideCandWnd(This,bShow)

#define IKoreanImeUI_SetCandData(This,dwSize,lpCandList)	\
    (This)->lpVtbl -> SetCandData(This,dwSize,lpCandList)

#define IKoreanImeUI_RedrawCandWnd(This)	\
    (This)->lpVtbl -> RedrawCandWnd(This)

#define IKoreanImeUI_SetCandWndPos(This,dwFlag,pRect,x,y)	\
    (This)->lpVtbl -> SetCandWndPos(This,dwFlag,pRect,x,y)

#define IKoreanImeUI_ShowHideCompWnd(This,bShow)	\
    (This)->lpVtbl -> ShowHideCompWnd(This,bShow)

#define IKoreanImeUI_SetCompData(This,dwCompLen,lpCompStr)	\
    (This)->lpVtbl -> SetCompData(This,dwCompLen,lpCompStr)

#define IKoreanImeUI_RedrawCompWnd(This)	\
    (This)->lpVtbl -> RedrawCompWnd(This)

#define IKoreanImeUI_SetCompWndPos(This,x,y)	\
    (This)->lpVtbl -> SetCompWndPos(This,x,y)

#define IKoreanImeUI_InitializeUIWindows(This,hMainWnd)	\
    (This)->lpVtbl -> InitializeUIWindows(This,hMainWnd)

#define IKoreanImeUI_UninitializeUIWindows(This)	\
    (This)->lpVtbl -> UninitializeUIWindows(This)

#define IKoreanImeUI_GetCompositionFont(This,dwSize,pLogFont)	\
    (This)->lpVtbl -> GetCompositionFont(This,dwSize,pLogFont)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_GetStatusWndPos_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [out] */ long __RPC_FAR *px,
    /* [out] */ long __RPC_FAR *py);


void __RPC_STUB IKoreanImeUI_GetStatusWndPos_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_GetCompWndPos_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [out] */ long __RPC_FAR *px,
    /* [out] */ long __RPC_FAR *py);


void __RPC_STUB IKoreanImeUI_GetCompWndPos_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_GetCandWndPos_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [out] */ long __RPC_FAR *px,
    /* [out] */ long __RPC_FAR *py);


void __RPC_STUB IKoreanImeUI_GetCandWndPos_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_ShowHideStatusWnd_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [in] */ int bShow);


void __RPC_STUB IKoreanImeUI_ShowHideStatusWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_SetStatusData_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [in] */ DWORD dwState);


void __RPC_STUB IKoreanImeUI_SetStatusData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_RedrawStatusWnd_Proxy( 
    IKoreanImeUI __RPC_FAR * This);


void __RPC_STUB IKoreanImeUI_RedrawStatusWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_SetStatusWndPos_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [in] */ long x,
    /* [in] */ long y);


void __RPC_STUB IKoreanImeUI_SetStatusWndPos_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_ShowHideCandWnd_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [in] */ int bShow);


void __RPC_STUB IKoreanImeUI_ShowHideCandWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_SetCandData_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [in] */ DWORD dwSize,
    /* [size_is][in] */ BYTE __RPC_FAR *lpCandList);


void __RPC_STUB IKoreanImeUI_SetCandData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_RedrawCandWnd_Proxy( 
    IKoreanImeUI __RPC_FAR * This);


void __RPC_STUB IKoreanImeUI_RedrawCandWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_SetCandWndPos_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [in] */ DWORD dwFlag,
    /* [in] */ RECT __RPC_FAR *pRect,
    /* [in] */ long x,
    /* [in] */ long y);


void __RPC_STUB IKoreanImeUI_SetCandWndPos_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_ShowHideCompWnd_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [in] */ int bShow);


void __RPC_STUB IKoreanImeUI_ShowHideCompWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_SetCompData_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [in] */ DWORD dwCompLen,
    /* [size_is][in] */ WCHAR __RPC_FAR *lpCompStr);


void __RPC_STUB IKoreanImeUI_SetCompData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_RedrawCompWnd_Proxy( 
    IKoreanImeUI __RPC_FAR * This);


void __RPC_STUB IKoreanImeUI_RedrawCompWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_SetCompWndPos_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [in] */ long x,
    /* [in] */ long y);


void __RPC_STUB IKoreanImeUI_SetCompWndPos_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_InitializeUIWindows_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [defaultvalue][in] */ HWND hMainWnd);


void __RPC_STUB IKoreanImeUI_InitializeUIWindows_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_UninitializeUIWindows_Proxy( 
    IKoreanImeUI __RPC_FAR * This);


void __RPC_STUB IKoreanImeUI_UninitializeUIWindows_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IKoreanImeUI_GetCompositionFont_Proxy( 
    IKoreanImeUI __RPC_FAR * This,
    /* [in] */ DWORD dwSize,
    /* [size_is][out] */ BYTE __RPC_FAR *pLogFont);


void __RPC_STUB IKoreanImeUI_GetCompositionFont_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IKoreanImeUI_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  HWND_UserSize(     unsigned long __RPC_FAR *, unsigned long            , HWND __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  HWND_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, HWND __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  HWND_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, HWND __RPC_FAR * ); 
void                      __RPC_USER  HWND_UserFree(     unsigned long __RPC_FAR *, HWND __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


