//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
// KoreanImeUI.cpp : Implementation of CKoreanImeUI
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
#include "stdafx.h"
#include "Kimeui.h"
#include "KoreanImeUI.h"

#include "uiInfo.h"

// externals.. 
extern HINSTANCE g_hInst;

extern LPVOID g_lpSharedUIPos;
#define g_uiInfo	(*(UIINFO *)g_lpSharedUIPos)  
#define g_fdwFixedCand	(*(LPDWORD)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)+sizeof(RECT)+sizeof(RECT)))
#define g_fdwVertCand	(*(LPDWORD)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)+sizeof(RECT)+sizeof(RECT)+sizeof(DWORD)))
#define g_fdwAutoCandAccel	(*(LPDWORD)((LPBYTE)g_lpSharedUIPos+sizeof(UIINFO)+sizeof(RECT)+sizeof(RECT)+sizeof(DWORD)*2))

extern void UpdateUIPosition();
extern LPCANDIDATELIST g_lpCandList;

extern WCHAR g_szCompStr[];
extern DWORD g_dwStateFlag;
extern void GetCandPos(HWND hWnd, DWORD dwFlag, const RECT *pRect, POINT &pt);
extern BOOL IsSIPOn();
extern HFONT hFontFix;

extern const TCHAR g_szIMEUIKey[]=TEXT("ControlPanel\\Korean IME UI\\Settings");
extern const TCHAR g_szShowCompUI[]=TEXT("ShowComp");	// dword: 0 or 1   default : 1
extern const TCHAR g_szShowCandUI[]=TEXT("ShowCand");   // dword: 0 or 1   default : 1
extern const TCHAR g_szShowStateUI[]=TEXT("ShowState"); // dword: 0 or 1   default : 1
extern int g_nCandSizeX, g_nCandSizeY;
extern SIZE g_sizeUnit;
extern RECT rcVIndex[], rcVButton[], rcPage;
extern SIZE sizeCandScroll;
extern POINT ptCandScroll;

#define MARGIN_X	2
#define MARGIN_Y	1

/////////////////////////////////////////////////////////////////////////////
// CKoreanImeUI

CKoreanImeUI::CKoreanImeUI(void)
{
	m_lRefCount = 0;
	m_hWndState = m_hWndCand = m_hWndComp = m_hWndCandScroll = m_hMainWnd = NULL;
}

CKoreanImeUI::~CKoreanImeUI(void)
{
}

// IKorenImeUI methods
BOOL CalcVCand(const CANDIDATELIST * lpCandList)
{
	HDC hDC = GetDC(NULL);
	TCHAR szTmp[2];
	SIZE Size;
	int tempCX;
	DWORD iCount;
	BOOL bRet=TRUE; // show or hide scroll bar
	
	szTmp[0]=0xac00; szTmp[1]=0;
	GetTextExtentPoint(GetDC(NULL), szTmp, lstrlen(szTmp), &Size);

	Size.cy += MARGIN_Y;

	RETAILMSG(1,(TEXT("CalcVCand() - Size = %d, %d\n"), Size.cx, Size.cy));
	if (lpCandList) {
		if (lpCandList->dwCount  <= lpCandList->dwPageSize) {
			bRet = FALSE;
			iCount = lpCandList->dwCount;
		}
		else
			iCount = lpCandList->dwPageSize;
		RETAILMSG(1,(TEXT("CalcVCand() - iCount = %d,\n"), iCount, lpCandList->dwCount));
	}
	else {
		iCount = 5;
	}
	g_sizeUnit = Size;

	sizeCandScroll.cx = GetSystemMetrics(SM_CXVSCROLL); // = 12;
	sizeCandScroll.cy = (Size.cy+1)*iCount;
	if (g_fdwAutoCandAccel && IsSIPOn()) {
		g_nCandSizeX = Size.cx*2 + (bRet ? sizeCandScroll.cx : 0);// + MARGIN_X;
	}
	else {
		g_nCandSizeX = Size.cx*3 + (bRet ? sizeCandScroll.cx : 0);// + MARGIN_X;
	}
	ptCandScroll.x = g_nCandSizeX - sizeCandScroll.cx - 1;
	rcPage.right = g_nCandSizeX - 1; // (Size.cx+1)*2 + (bRet ? sizeCandScroll.cx : 0);

	g_nCandSizeY = (Size.cy+MARGIN_Y)*iCount + Size.cy + MARGIN_Y;
	rcPage.left = 0; rcPage.top = (Size.cy+MARGIN_Y)*iCount;
	rcPage.bottom = (Size.cy+MARGIN_Y)*iCount + Size.cy;
	ptCandScroll.y = 0;

	tempCX = bRet? g_nCandSizeX - sizeCandScroll.cx : g_nCandSizeX -1 ;

	DWORD i;
	if (g_fdwAutoCandAccel && IsSIPOn()) {
		for (i=0; i < iCount; i++) {
			rcVIndex[i].left = 0;	rcVButton[i].left = 0;
			rcVIndex[i].top = 0; 	rcVButton[i].top = i*(Size.cy+MARGIN_Y);
			rcVIndex[i].right = 0; 	rcVButton[i].right = tempCX;
			rcVIndex[i].bottom = 0; rcVButton[i].bottom = (i+1)*(Size.cy+MARGIN_Y);
		}
	}
	else {
		for (i=0; i < iCount; i++) {
			rcVIndex[i].left = 0;	rcVButton[i].left = Size.cx;
			rcVIndex[i].top = rcVButton[i].top = i*(Size.cy+MARGIN_Y);
			rcVIndex[i].right = Size.cx;	rcVButton[i].right = tempCX;
			rcVIndex[i].bottom = rcVButton[i].bottom = (i+1)*(Size.cy+MARGIN_Y);
		}
	}
	return bRet;
}

void SetScrBarInfo(HWND hScrBar, int nMin, int nMax, UINT nPage, int nPos)
{
    SCROLLINFO si;

    si.cbSize= sizeof(SCROLLINFO);
    si.fMask= SIF_PAGE | SIF_POS | SIF_RANGE;
    si.nMin = nMin;
    si.nMax = nMax;
    si.nPage= nPage;
    si.nPos = nPos;

    SetScrollInfo(hScrBar, SB_CTL, &si, TRUE);

    return;
}

// Global
STDMETHODIMP CKoreanImeUI::InitializeUIWindows(HWND hMainWnd)
{
	DWORD fShowCompUI=1;
	DWORD fShowCandUI=1;
	DWORD fShowStateUI=0;
	HRESULT hr=S_OK;

	m_hMainWnd = hMainWnd;
#ifndef WPC
	HKEY hKey;
	DWORD dwSize = sizeof(DWORD);
	fShowStateUI=1;
	if (RegOpenKeyEx(HKEY_CURRENT_USER, g_szIMEUIKey, 0, 0 , &hKey) == ERROR_SUCCESS) {
		RegQueryValueEx(hKey, g_szShowCompUI, NULL, NULL, (LPBYTE)&fShowCompUI, &dwSize);
		dwSize = sizeof(DWORD);
		RegQueryValueEx(hKey, g_szShowCandUI, NULL, NULL, (LPBYTE)&fShowCandUI, &dwSize);
		dwSize = sizeof(DWORD);
		RegQueryValueEx(hKey, g_szShowStateUI, NULL, NULL, (LPBYTE)&fShowStateUI, &dwSize);
	}
#endif // !WPC

	if (g_fdwVertCand) {
		CalcVCand(NULL);
	}
	else {
		g_nCandSizeX = CANDXSIZE;
		g_nCandSizeY = CANDYSIZE;
	}
	UpdateUIPosition();
	if (fShowStateUI && !m_hWndState) {
		m_hWndState = CreateWindowEx(WS_EX_TOPMOST|WS_EX_NOACTIVATE|WS_EX_TOOLWINDOW, TEXT("UNIIMESTATE"), NULL,//TEXT("State"),
							WS_POPUP, g_uiInfo.ptState.x, g_uiInfo.ptState.y,
							STATEXSIZE, STATEYSIZE, 
							NULL, NULL, g_hInst, NULL);
		if (!m_hWndState)
			hr = E_FAIL;
		else 
			SetWindowLong(m_hWndState, GWL_USERDATA, (long)m_hMainWnd);
	}
	if (fShowCompUI && !m_hWndComp) {
		m_hWndComp = CreateWindowEx(WS_EX_TOPMOST|WS_EX_NOACTIVATE|WS_EX_TOOLWINDOW, TEXT("UNIIMECOMP"), NULL, //TEXT("Comp"),
							WS_POPUP, g_uiInfo.ptComp.x, g_uiInfo.ptComp.y,
							COMPSIZE, COMPSIZE, NULL, NULL, g_hInst, NULL );
		if (!m_hWndComp)
			hr = E_FAIL;
	}
	if (fShowCandUI && !m_hWndCand) {
		m_hWndCand = CreateWindowEx(WS_EX_TOPMOST|WS_EX_NOACTIVATE|WS_EX_TOOLWINDOW, TEXT("UNIIMECAND"), NULL, // TEXT("Cand"),
							WS_POPUP, g_uiInfo.ptCand.x, g_uiInfo.ptCand.y,
							g_nCandSizeX, g_nCandSizeY, NULL, NULL, g_hInst, NULL );
		if (!m_hWndCand) {
			hr = E_FAIL;
		}
		else {
			if (g_fdwVertCand)
				m_hWndCandScroll = CreateWindow(TEXT("scrollbar"), NULL, WS_CHILD|SBS_VERT,
	            	ptCandScroll.x, ptCandScroll.y, sizeCandScroll.cx, sizeCandScroll.cy,
	            	m_hWndCand, (HMENU)1, g_hInst, NULL);
	        SetWindowLong(m_hWndCand, GWL_USERDATA, (long)m_hMainWnd);
        }
	}
	return hr;
}

STDMETHODIMP CKoreanImeUI::UninitializeUIWindows()
{
	UpdateUIPosition();
	if (m_hWndState)
		DestroyWindow(m_hWndState);
	if (m_hWndComp)
		DestroyWindow(m_hWndComp);
	if (m_hWndCand) {
		if (m_hWndCandScroll)
			DestroyWindow(m_hWndCandScroll);
		DestroyWindow(m_hWndCand);
	}
	m_hWndState = m_hWndCand = m_hWndComp = NULL;
	return S_OK;
}
// Candidate Window stuffs
STDMETHODIMP CKoreanImeUI::GetCandWndPos(long *px, long *py)
{
	if (m_hWndCand) {
		*px = g_uiInfo.ptCand.x;
		*py = g_uiInfo.ptCand.y;
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::SetCandWndPos(DWORD dwFlag, RECT *pRect, long x, long y)
{
	POINT pt = {x, y};
	if (m_hWndCand && !g_fdwFixedCand) {
		GetCandPos(m_hWndCand, dwFlag, pRect, pt);
		g_uiInfo.ptCand = pt;
		MoveWindow(m_hWndCand, g_uiInfo.ptCand.x, g_uiInfo.ptCand.y, g_nCandSizeX, g_nCandSizeY, TRUE);
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::ShowHideCandWnd(int bShow)
{
	if (m_hWndCand) {
		ShowWindow(m_hWndCand, (bShow && g_lpCandList) ? SW_SHOWNOACTIVATE : SW_HIDE);
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::SetCandData(DWORD dwSize, BYTE *lpCandList)
{
	if (m_hWndCand) {
		if (g_lpCandList)
			LocalFree(g_lpCandList);
		if (dwSize == 0) {
			g_lpCandList = NULL;
			return S_OK;
		}
		g_lpCandList = (LPCANDIDATELIST) LocalAlloc(LPTR, dwSize);
		if (g_lpCandList)
			memcpy(g_lpCandList, lpCandList, dwSize);
		else
			return E_OUTOFMEMORY;

		
		if (g_fdwVertCand) {
//			if (m_hWndCandScroll)
//				DestroyWindow(m_hWndCandScroll);
			if (CalcVCand(g_lpCandList)) {
				MoveWindow(m_hWndCand, g_uiInfo.ptCand.x, g_uiInfo.ptCand.y, g_nCandSizeX, g_nCandSizeY, TRUE);
				if (m_hWndCandScroll) {
					MoveWindow(m_hWndCandScroll, ptCandScroll.x, ptCandScroll.y, sizeCandScroll.cx, sizeCandScroll.cy, TRUE);
					ShowWindow(m_hWndCandScroll, SW_SHOW);
			        SetScrBarInfo(m_hWndCandScroll, 0, g_lpCandList->dwCount - 1, g_lpCandList->dwPageSize, g_lpCandList->dwPageStart);
		        }
	            RETAILMSG(1,(TEXT("CKoreanImeUI::SetCandData() : m_hWndCandScroll = 0x%x\n"), m_hWndCandScroll));
	        }
	        else {
	        	if (m_hWndCandScroll) {
		        	ShowWindow(m_hWndCandScroll, SW_HIDE);
		        	MoveWindow(m_hWndCand, g_uiInfo.ptCand.x, g_uiInfo.ptCand.y, g_nCandSizeX, g_nCandSizeY, TRUE);
		        }
	        }
		}
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::RedrawCandWnd()
{
	if (m_hWndCand) {
		InvalidateRect(m_hWndCand, NULL, TRUE);
		UpdateWindow(m_hWndCand);
		return S_OK;
	}
	return E_FAIL;
}

// Composition Window Stuffs
STDMETHODIMP CKoreanImeUI::GetCompWndPos(long *px, long *py)
{
	if (m_hWndComp) {
		*px = g_uiInfo.ptComp.x;
		*py = g_uiInfo.ptComp.y;
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::SetCompWndPos(long x, long y)
{
	if (m_hWndComp) {
		g_uiInfo.ptComp.x = x;
		g_uiInfo.ptComp.y = y;
		MoveWindow(m_hWndComp, g_uiInfo.ptComp.x, g_uiInfo.ptComp.y, COMPSIZE, COMPSIZE, TRUE);
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::ShowHideCompWnd(int bShow)
{
	if (m_hWndComp) {
		ShowWindow(m_hWndComp, (bShow && g_szCompStr[0]) ? SW_SHOWNOACTIVATE : SW_HIDE);
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::SetCompData(DWORD dwCompLen, WCHAR *lpCompStr)
{
	if (m_hWndComp) {
		if (dwCompLen && lpCompStr) {
			g_szCompStr[0] = lpCompStr[0];
			g_szCompStr[1] = 0;
		}
		else {
			g_szCompStr[0] = g_szCompStr[1] = 0;
		}
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::RedrawCompWnd()
{
	if (m_hWndComp) {
		InvalidateRect(m_hWndComp, NULL, TRUE);
		UpdateWindow(m_hWndComp);
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::GetStatusWndPos(long *px, long *py)
{
	if (m_hWndState) {
		*px = g_uiInfo.ptState.x;
		*py = g_uiInfo.ptState.y;
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::SetStatusWndPos(long x, long y)
{
	if (m_hWndState) {
		g_uiInfo.ptState.x = x;
		g_uiInfo.ptState.y = y;
		MoveWindow(m_hWndState, g_uiInfo.ptState.x, g_uiInfo.ptState.y, STATEXSIZE, STATEYSIZE, TRUE);
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::ShowHideStatusWnd(int bShow)
{
	if (m_hWndState) {
		ShowWindow(m_hWndState, (bShow ? SW_SHOWNOACTIVATE : SW_HIDE));
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::SetStatusData(DWORD dwState)
{
	if (m_hWndState) {
		g_dwStateFlag = dwState;
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::RedrawStatusWnd()
{
	if (m_hWndState) {
		LONG lStyle = GetWindowLong(m_hWndState, GWL_STYLE);
		if (lStyle & WS_VISIBLE) {
			InvalidateRect(m_hWndState, NULL, TRUE);
			UpdateWindow(m_hWndState);
		}
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CKoreanImeUI::GetCompositionFont(DWORD dwSize, BYTE *pLogFont)
{
	return E_FAIL;
}

