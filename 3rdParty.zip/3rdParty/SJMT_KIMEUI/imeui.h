//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//

class CKoreanImeUI : public IKoreanImeUI
{
public:
	CKoreanImeUI(void);
	~CKoreanImeUI();

	// IUnknown

	STDMETHOD (QueryInterface) (REFIID iid, void ** pp);
	STDMETHOD_(ULONG, AddRef) ();
	STDMETHOD_(ULONG, Release) ();

	// IKoreanImeUI
	STDMETHOD (InitializeUIWindows)( void);
	STDMETHOD (QueryImeUISpec)( LPIMEUISPEC lpIMEUISpec );

	STDMETHOD (GetStatusWndPos)( PPOINT pPos );
	STDMETHOD (GetCompWndPos)( PPOINT pPos );
	STDMETHOD (GetCandWndPos)( PPOINT pPos );

	STDMETHOD (OpenStatusWnd)( DWORD dwState );
	STDMETHOD (RedrawStatusWnd)( DWORD dwState );
	STDMETHOD (CloseStatusWnd)( void );
	STDMETHOD (SetStatusWndPos)( PPOINT pPos );

	STDMETHOD (OpenCandWnd)( DWORD dwCount, DWORD dwSelection, DWORD dwPageSize, WCHAR *lpCandStr );
	STDMETHOD (RedrawCandWnd)( DWORD dwCount, DWORD dwSelection, DWORD dwPageSize, WCHAR *lpCandStr );
	STDMETHOD (CloseCandWnd)( void );
	STDMETHOD (SetCandWndPos)( PPOINT pPos);

	STDMETHOD (OpenCompWnd)( DWORD dwCompLen, WCHAR *lpCompStr );
	STDMETHOD (RedrawCompWnd)( DWORD dwCompLen, WCHAR *lpCompStr );
	STDMETHOD (CloseCompWnd)( void );
	STDMETHOD (SetCompWndPos)( PPOINT );

private:
	ULONG m_lRefCount;
};
