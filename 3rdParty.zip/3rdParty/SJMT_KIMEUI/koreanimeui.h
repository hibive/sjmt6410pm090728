//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
// KoreanImeUI.h : Declaration of the CKoreanImeUI
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//

#ifndef __KOREANIMEUI_H_
#define __KOREANIMEUI_H_

#include "resource.h"       // main symbols

#define WM_IMEUI_REQ_CHANGECAND		(WM_USER + 100)

/////////////////////////////////////////////////////////////////////////////
// CKoreanImeUI
class ATL_NO_VTABLE CKoreanImeUI : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CKoreanImeUI, &CLSID_KoreanImeUI>,
	public IDispatchImpl<IKoreanImeUI, &IID_IKoreanImeUI, &LIBID_KIMEUILib>
{
public:
	CKoreanImeUI();
	~CKoreanImeUI();

DECLARE_REGISTRY_RESOURCEID(IDR_KOREANIMEUI)
DECLARE_NOT_AGGREGATABLE(CKoreanImeUI)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CKoreanImeUI)
	COM_INTERFACE_ENTRY(IKoreanImeUI)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IKoreanImeUI
public:

	__override STDMETHODIMP GetStatusWndPos( long *px, long *py );
	__override STDMETHODIMP GetCompWndPos( long *px, long *py );
	__override STDMETHODIMP GetCandWndPos( long *px, long *py );

	__override STDMETHODIMP ShowHideStatusWnd( int bShow );
	__override STDMETHODIMP SetStatusData( DWORD dwState );
	__override STDMETHODIMP RedrawStatusWnd( void );
	__override STDMETHODIMP SetStatusWndPos( long x, long y );

	__override STDMETHODIMP ShowHideCandWnd( int bShow );
	__override STDMETHODIMP SetCandData( DWORD dwSize, BYTE *lpCandList );
	__override STDMETHODIMP RedrawCandWnd( void );
	__override STDMETHODIMP SetCandWndPos( DWORD dwFlag, RECT *pRect, long x, long y);

	__override STDMETHODIMP ShowHideCompWnd( int bShow );
	__override STDMETHODIMP SetCompData( DWORD dwCompLen, WCHAR *lpCompStr );
	__override STDMETHODIMP RedrawCompWnd( void );
	__override STDMETHODIMP SetCompWndPos( long x, long y );

	__override STDMETHODIMP InitializeUIWindows( HWND hMainWnd = NULL);
	__override STDMETHODIMP UninitializeUIWindows( void);

	__override STDMETHODIMP GetCompositionFont(DWORD dwSize, BYTE *pLogFont);
//	__override STDMETHODIMP RegisterMainWnd(HWND hMainWnd);

private:
	ULONG m_lRefCount;
	HWND m_hWndState;
	HWND m_hWndCand;
	HWND m_hWndComp;
	HWND m_hWndCandScroll;
	HWND m_hMainWnd;

};

#endif //__KOREANIMEUI_H_
