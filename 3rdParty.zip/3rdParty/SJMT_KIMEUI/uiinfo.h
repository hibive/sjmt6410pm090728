//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
#ifndef UIINFO_H
#define UIINFO_H

typedef struct _tagUIINFO {
	POINT ptDefPos[3];
	POINT ptState;
	POINT ptComp;
	POINT ptCand;
} UIINFO;

typedef struct _tagUIWNDS {
	HWND hWndState;
	HWND hWndComp;
	HWND hWndCand;
} UIWNDS;

typedef struct tagUIINSTANCE
{
    HWND    rghWnd[3];
    LPVOID  pKoreanImeUI;
}   UIINSTANCE;
typedef UIINSTANCE NEAR *PUIINSTANCE;
typedef UIINSTANCE FAR  *LPUIINSTANCE;

#define COMP_WINDOW     0
#define STATE_WINDOW    1
#define CAND_WINDOW     2

#define STATEXSIZE      49
#define STATEYSIZE      25
#define COMPSIZE        22
#define CANDXSIZE       239
#define CANDYSIZE       30
#define GAPX            10
#define GAPY            0
#define BUTTONSIZEX		18
#define BUTTONSIZEY		18

#endif